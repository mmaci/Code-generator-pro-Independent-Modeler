 public Interface1 {
	 public Class2 imetoda ( Class2 a ) {



			}



}
