 public Enum1 {
	 public Class2 atr1;



	 private Class1 class11;




}
