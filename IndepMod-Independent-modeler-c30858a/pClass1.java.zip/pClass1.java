 public Class1 {
	 @anot11( a =" 1 " )
	 protected Class2 atr11;


	 private Class3 class31;
	 private List<Class2> class21;


	 private Enum1 enum12;
	 Class2 metoda11 ( ) {



		 @anot11( a =" 1 " )
		 protected Class2 atr11;



	}
}
