 public Class2 extends Class6 implements Interface1 {
	 private Class2 atr2;


	 private Enum1 enum11;


	 private Class4 class41;
	 private Class1 class11;


}
