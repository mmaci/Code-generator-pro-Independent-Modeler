 public Class6 {



	 private Class2 metoda6 ( ) {




			}
}
